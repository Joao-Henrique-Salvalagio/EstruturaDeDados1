#include <stdio.h>

int main (void){
	char nomes [3][10];
	float notas [3];
	
	int i;
	
	for (i=0; i<3; i++){
		printf("Digite nome e nota do estudante: ");
		scanf("%s%f", &nomes[i], &notas [i]);
	}
	
	printf("\nNome\t\tNota\n");
	for(i=0; i<3; i++){
		printf("%s\t\t%.2f\n", nomes[i], notas[i]);
	}
	
	
}
